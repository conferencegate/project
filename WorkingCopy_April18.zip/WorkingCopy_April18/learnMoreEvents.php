<?php
  session_start();
?>

<html>
<head>
  <title> Show Events | Conference Gate</title>

     <meta charset="utf-8"> 
    <meta name="description" content="Bootstrap.">  
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">   
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css"></style>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>


</head>
<head>
  <div class="topnav">
  <a class="active" href="1_mainpage.php"><b><font color="black">Conference Gate</font></b></a>
  <a href="aboutUs.html"><b>About<b></a>

<div class="login-container">
    <form action="/2_userregistration.php">  
      <button type="submit"><b>Create New Account<b></button>
    </form>
  </div>

  <div class="login-container">
    <form action="/3_login.php">     
      <button type="submit"><b>Login<b></button>
    </form>
  </div>
</div>


<style type="text/css">
    /* Add a black background color to the top navigation */
.topnav {
  background-color: #318ce7;
  overflow: hidden;
}

/* Style the input container */
.topnav .login-container {
  float: right;
}

/* Style the button inside the input container */
.topnav .login-container button {
  float: right;
  padding: 6px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 14px;
  border: none;
  cursor: pointer;
}

/* Style when you hover on each tab */
.topnav .login-container button:hover {
  background: #ccc;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #ccc;
  color: white;
}
footer 
    {
        background-color: black;
        padding: 7px;
        text-align: center;
        color: white;
        position: sticky;
        position: absolute;
  /* negative value of footer height */
        height: 30px;
        width: 100%;
        clear:both;
        bottom: 0;
}
  </style>

<?php
  session_start();
?>
<html>

<body>
  <div class="container">
  <?php
    $servername = "localhost";
    $username = "root";
    $password = "mysql";
    $dbname = "conferencegate";

  // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 

    $confID = $_GET["conferenceID"];

    // Run an sql
    $sql = "SELECT c.name as cname, e.title, e.room, e.eventTime, l.name, l.address, l.city
      FROM Conference c, Location l, Event e
      WHERE c.locationID = l.locationID AND c.conferenceID = e.conferenceID AND c.conferenceID =".$confID;
    $result = $conn->query($sql);
  ?>

<table id="myTable" class="table table-striped" width="100%" cellspacing="0">
    <tr>
     
      <br>
      <th>Name of Event(s)</th>
      <th>Room</th>
      <th>Time</th>
      <th>Location</th>
      <th>Address</th>
      <th>City</th>

  
    </tr>
  

      <?php
      if ($result -> num_rows > 0) {
        while($row = $result->fetch_assoc()) {
        echo 

        "<b>Event(s) at " . $row['cname'] .
        "</b>
        <br>
        <tr>
        <td>" . stripslashes($row["title"]) . "</td>
        <td>" . $row["room"] . "</td>
        <td>" . $row["eventTime"] . "</td>
        <td>" . $row["name"] . "</td>
        <td>" . $row["address"] . "</td>
        <td>" . $row["city"] . "</td>
        </tr>";
        
        }
      }

      else {
        echo "<b>No Events Posted Yet<b><br>" . 
        "
        <tr>
        <td>" . "To Be Decided (TBD)"  . "</td>
        <td>" . "TBD" . "</td>
        <td>" . "TBD"  . "</td>
        <td>" . "TBD"  . "</td>
        <td>" . "TBD"  . "</td>
        <td>" . "TBD"  . "</td>";
      }
      ?>

  </table>
</div>

  <?php
  // Close connection
  mysqli_close($conn);
?>

 <footer>
  © 2019 Copyright by ConferenceGate
</footer>
</body>
</html>