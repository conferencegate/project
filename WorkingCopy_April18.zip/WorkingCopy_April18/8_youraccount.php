<?php
  session_start();
?>

<!--TOP NAV AREA !-->
<html>
<head>
    <div class="topnav">
  <a class="active" href="1_mainpage.php"><b><font color="black">Conference Gate</font></b></a>
  <a href="aboutUs.php"><b>About</b></a>
  <a href="16_logout.php"><b>Logout</b></a>

</div>


<style type="text/css">
        /* Add a black background color to the top navigation */
.topnav {
  background-color: #318ce7;
  overflow: hidden;
}

/* Style the input container */
.topnav .login-container {
  float: right;
}

/* Style the button inside the input container */
.topnav .login-container button {
  float: right;
  padding: 6px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 14px;
  border: none;
  cursor: pointer;
}

/* Style when you hover on each tab */
.topnav .login-container button:hover {
  background: #ccc;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #ccc;
  color: white;
}
footer 
    {
        background-color: black;
        padding: 7px;
        text-align: center;
        color: white;
        position: absolute;
        /* negative value of footer height */
        height: 30px;
        width: 100%;
        clear:both;
        bottom: 0;
    }
</style>


<div class="main">
  <h1>My Account Information</h1>

</div>

<?php
$servername = "localhost";
$username = "root";
$password = "mysql";
$dbname = "conferencegate";

ini_set('max_execution_time',300);

// Create Connection 
$conn = new mysqli($servername, $username, $password, $dbname);

// Check Connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT firstName, lastName, discipline, organization, email FROM Attendee WHERE userID = ".$_SESSION['userID'];
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table>";
  
    while ($row = mysqli_fetch_assoc($result)){

      echo
      "<tr><td>". 

      "First Name: " .
      $row['firstName'] . 
      "</tr><td>" . 

      "Last Name: " .
      $row['lastName'] . 
      "</tr><td>" . 

      "Discipline: " .
      $row['discipline'] . 
      "</tr><td>" . 

      "Organization: " .
      $row['organization'] . 
      "</tr><td>" .

      "Email: " .
      $row['email'] . 
      "</td></tr>";
   
  }
    echo "</table>";
}

// Option to update your personal information
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
  echo "<a href='/11_changeInfo.php' class='button'>Update Info</a>";
}

// Find conferences you are attending
$sql2 = "SELECT c.conferenceID, c.name as cname, c.startDate, c.endDate FROM Conference c, Registration r WHERE c.conferenceID = r.conferenceID AND r.userID = ".$_SESSION['userID'];
$result2 = $conn->query($sql2);

?>
  <br>
  <table border="1">
    <caption><b>Conferences You Are Registered For</b></caption>
    <tr>

      <th>Learn More</th>
      <th>Name</th>
      <th>Start Date</th>
      <th>End Date</th>
    </tr>

      <?php
      if ($result2) {
        while($row2 = $result2->fetch_assoc()) {
        echo "<tr>
        <td><a href=learnMoreEvents.php?conferenceID=". $row2["conferenceID"] . ">Show Events</a></td>
        <td>" . stripslashes($row2["cname"]) . "</td>
        <td>" . $row2["startDate"] . "</td>
        <td>" . $row2["endDate"] . "</td>
        </tr>";
        }
      }

      ?>

  </table>
</head>

<h3>Check out upcoming conferences!</h3>
<meta charset="utf-8">
<style>
.bar {
  fill: steelblue;
}
.bar:hover {
  fill: brown;
}
.axis--x path {
  display: none;
}
</style>
<svg width="450" height="300"></svg>
<script src="https://d3js.org/d3.v4.min.js"></script>
<script>
var svg = d3.select("svg"),
    margin = {top: 20, right: 20, bottom: 30, left: 40},
    width = +svg.attr("width") - margin.left - margin.right,
    height = +svg.attr("height") - margin.top - margin.bottom;
var x = d3.scaleBand().rangeRound([0, width]).padding(0.1),
    y = d3.scaleLinear().rangeRound([height, 0]);
var g = svg.append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
d3.tsv("./data.php?action=<?php echo $_GET[action];?>", function(d) {
  d.frequency = +d.frequency;
  return d;
}, function(error, data) {
  if (error) throw error;
  x.domain(data.map(function(d) { return d.letter; }));
  y.domain([0, d3.max(data, function(d) { return d.frequency; })]);
  g.append("g")
      .attr("class", "axis axis--x")
      .attr("transform", "translate(0," + height + ")")
      .call(d3.axisBottom(x));
  g.append("g")
      .attr("class", "axis axis--y")
      .call(d3.axisLeft(y).ticks(10, ""))
    .append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", 6)
      .attr("dy", "0.71em")
      .attr("text-anchor", "end")
      .text("Frequency");
  g.selectAll(".bar")
    .data(data)
    .enter().append("rect")
      .attr("class", "bar")
      .attr("x", function(d) { return x(d.letter); })
      .attr("y", function(d) { return y(d.frequency); })
      .attr("width", x.bandwidth())
      .attr("height", function(d) { return height - y(d.frequency); });
});
</script>
<br>
<a href="./8_youraccount.php?action=conferencesbydiscipline">See Which Disciplines Have Conferences this Month</a> <br>
<a href="./8_youraccount.php?action=highattn">This Year's Highest-Attended Conferences</a> <br>
<a href="./8_youraccount.php?action=hotlocation">This Month's Hottest Conference Destinations</a> <br>
<footer>
  © 2019 Copyright by ConferenceGate
</footer>
</html>