<?php
  session_start();
?>

<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <title>Search Conference | Conference Gate</title>
</head>
  <div class="topnav">
  <a class="active" href="1_mainpage.php"><b><font color="black">Conference Gate</font></b></a>
  <a href="aboutUs.php"><b>About</b></a>
  <?php
  // Check if user is logged in and assign logout buttons accordingly
    if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    echo "<a href='16_logout.php'>Logout</a>";
  echo "<div class='login-container'>
    <form action='/8_youraccount.php'>  
    <button type='submit'><b>My Account</b></button>
    </form>
    </div>";
  }
  
  if(!isset($_SESSION["loggedin"]) && !$_SESSION["loggedin"] === true) {
    echo"<div class='login-container'>
        <form action='/2_userregistration.php'>  
          <button type='submit'><b>Create New Account</b></button>
        </form>
      </div>

      <div class='login-container'>
        <form action='/3_login.php'>     
          <button type='submit'><b>Login</b></button>
        </form>
      </div>";
    }
  ?>
  </div>

<style type="text/css">
    /* Add a black background color to the top navigation */
.topnav {
  background-color: #318ce7;
  overflow: hidden;
}

/* Style the input container */
.topnav .login-container {
  float: right;
}

/* Style the button inside the input container */
.topnav .login-container button {
  float: right;
  padding: 6px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 14px;
  border: none;
  cursor: pointer;
}

/* Style when you hover on each tab */
.topnav .login-container button:hover {
  background: #ccc;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #ccc;
  color: white;
}
footer {
  background-color: black;
  padding: 7px;
  text-align: center;
  color: white;
  position: absolute;
  /* negative value of footer height */
  height: 30px;
  width: 100%;
  clear:both;
  bottom: 0;
  flex-shrink: 0;
}
.container{
        max-width: 650px;
        max-height: 10px;
}
body {
  padding : 10px ;
  
}
h1 {text-align:center;}
p {text-align:center;}
.tab-content>.tab-pane {
  display: block;
  width: 600;
  height: 20;
}
.tab-content>.active {
  display: block;
  width: initial;
  height: initial;
}
#content-wrap {
  padding-bottom: 2.5rem;    /* Footer height */
}
</style>

<style>
h1 {text-align:center;}
p {text-align:center;}
</style>

  <body>
<br>
<p><h3>Search for a Specific Conference, Paper, or Event?  <img src="searchicon.png"  align="middle" style="width:50px; height:50px;" ></h3> </p>
<br><br>

<div class="container">
<ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" id="pills-Conference-tab" data-toggle="pill" href="#pills-Conference" role="tab" aria-controls="pills-Conference" aria-selected="true">Conference</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="pills-Contribution-tab" data-toggle="pill" href="#pills-Contribution" role="tab" aria-controls="pills-Contribution" aria-selected="true">Contribution</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="pills-Events-tab" data-toggle="pill" href="#pills-Events" role="tab" aria-controls="pills-Events" aria-selected="false">Events</a>
  </li>
</ul>



<div class="tab-content" id="pills-tabContent">

   <!-- Conference -->
  <div class="tab-pane fade in active" id="pills-Conference" role="tabpanel" aria-labelledby="pills-Conference-tab">
<br>
<div class="well">
<form action="12_searchResults.php" method="POST">
  <div class="form-group">
    <b>* Search by one or more:</b><br><br>
    <label for="Conference Name">Conference Name</label>
    <input type="text" class="form-control" id="cfname" name="cfname" placeholder="Conference Name">
  </div>


  <div class="form-group">
    <label for="City">City</label>
    <input type="text" class="form-control" id="cfcity" name="cfcity" placeholder="City">
  </div>
  

  <div class="form-group">
    <label for="Discipline">Discipline</label>
    <input type="text" class="form-control" id="cfdisc" name="cfdisc" placeholder="Discipline">
  </div>

  <div class="form-group">
  <label for="StartDate">Start Date Between</label>
  <input type="date" name="cfstartDate"> <b>And</b> <input type="date" name="cfstartDate2"></br>
  </div>

  <button type="submit" class="btn btn-primary">Search</button>
 </form>
</div>
</div>

  <!-- Contribution -->
  <div class="tab-pane fade" id="pills-Contribution" role="tabpanel" aria-labelledby="pills-Contribution-tab">
    <div class="well">
<form action="/12_searchResults.php" method="POST">
  <div class="form-group">

    <label for="Contribution Name">Contribution Name</label>
    <input type="text" class="form-control" id="contribution" name="contribution" placeholder="Contribution Name">
  </div>


  <button type="submit" class="btn btn-primary">Search</button>
 </form>
</div>
</div>

   <!-- Events -->
  <div class="tab-pane fade" id="pills-Events" role="tabpanel" aria-labelledby="pills-Events-tab">
    <div class="well">
    <form action="/12_searchResults.php" method="POST">
    <div class="form-group">

    <label for="Event Name">Event Name</label>
    <input type="text" class="form-control" id="event" name="event" placeholder="Event Name">
  </div>


  <button type="submit" class="btn btn-primary">Search</button>
 </form>
 </div>
  </div>
</div>


<script src="http://code.jquery.com/jquery-1.12.0.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<script type="text/javascript">
  jQuery(document).ready(function ($) {
        $('.nav li').tab();
    });
  $(".nav li").on("click", function() {
    // body...

    $(".nav li").removeClass("active");
    $("this").addClass("active");

  });
</script>
</div>

<footer>
  © 2019 Copyright by ConferenceGate
</footer>
  </body>
</html>