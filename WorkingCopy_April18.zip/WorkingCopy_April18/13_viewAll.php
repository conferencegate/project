<?php
  session_start();

  $servername = "localhost";
  $username = "root";
  $password = "mysql";
  $dbname = "conferencegate";

// Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  } 

  // Get variables from form
  $cfnameraw = $_POST["cfname"];
  $cfcityraw = $_POST["cfcity"];
  $cfdiscraw = $_POST["cfdisc"];
  $cfid = $_POST["cfid"];
  $cfopen = $_POST["cfopenReg"];
  $cfname = strtolower($cfnameraw);
  $cfcity = strtolower($cfcityraw);
  $cfdisc = strtolower($cfdiscraw);
  $cfstartDate = $_POST["cfstartDate"];
  $cfstartDate2 = $_POST["cfstartDate2"];

  // Make clauses to construct SQL
  if($cfid){$cfid_clause = " AND c.conferenceID = ".$cfid." ";}
  if($cfname){$cfname_clause = "AND LOWER(c.name) LIKE '%".$cfname."%' ";}
  if($cfcity){$cfcity_clause = "AND LOWER(l.city) LIKE '%".$cfcity."%' ";}
  if($cfdisc){$cfdisc_clause = "AND LOWER(c.discipline) LIKE '%".$cfdisc."%' ";}
  if($cfstartDate && $cfstartDate2){$cfdate_clause = "AND LOWER(l.city) LIKE '%".$cfcity."%' ";}

  // Run an sql
 $record_per_page = 100;
 $page = isset($_GET["page"]) ? $_GET["page"] : 1;

 $start_from = ($page-1)*$record_per_page;

  $sql = "SELECT c.conferenceID, c.name as cname, l.name, l.address, l.city, c.discipline, c.startDate, c.endDate
    FROM Conference c, Location l
    WHERE c.locationID = l.locationID LIMIT $start_from , $record_per_page".$cfid_clause.$cfname_clause.$cfcity_clause.$cfdisc_clause.$cfdate_clause;
  $result = $conn->query($sql);

   $Previous = $page - 1;
      $Next = $page + 1 ;
?>

<html>
<head>
  <meta charset="utf-8"> 
    <meta name="description" content="Bootstrap.">  
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">   
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css"></style>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>


  <title>Search Results | Conference Gate</title>

  <div class="topnav">
  <a class="active" href="1_mainpage.php"><b><font color="black">Conference Gate</font></b></a>
  <a href="aboutUs.php"><b>About</b></a>
  
  <?php   
  // Check if user is logged in and assign logout buttons accordingly
    if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    echo "<a href='16_logout.php'><b>Logout</b></a>";
  echo "<div class='login-container'>
    <form action='/8_youraccount.php'>  
    <button type='submit'><b>My Account</b></button>
    </form>
    </div>";
  }
  
  if(!isset($_SESSION["loggedin"]) && !$_SESSION["loggedin"] === true) {
    echo"<div class='login-container'>
        <form action='/2_userregistration.php'>  
          <button type='submit'><b>Create New Account</b></button>
        </form>
      </div>

      <div class='login-container'>
        <form action='/3_login.php'>     
          <button type='submit'><b>Login</b></button>
        </form>
      </div>";
    }
  ?>
  </div>
</head>

<style type="text/css">
    /* Add a black background color to the top navigation */
.topnav {
  background-color: #318ce7;
  overflow: hidden;
}

/* Style the input container */
.topnav .login-container {
  float: right;
}

/* Style the button inside the input container */
.topnav .login-container button {
  float: right;
  padding: 6px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 14px;
  border: none;
  cursor: pointer;
}

/* Style when you hover on each tab */
.topnav .login-container button:hover {
  background: #ccc;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #ccc;
  color: white;
}

footer 
    {
        background-color: black;
        padding: 7px;
        text-align: center;
        color: white;
        position: absolute;
        /* negative value of footer height */
        height: 30px;
        width: 100%;
        clear:both;
        bottom: 0;
}

table th:nth-child(3), td:nth-child(3) {
  display: none;
}
.navigation-bar .pagination {
      margin-top: 0;
      position: center;
    }

</style>

<html>
<body style="margin:1px auto">
<div class="container">
  <div class="row header" style="text-align:center;color:black">
<h3>Showing All Conferences</h3>
</div>
<?php 
  
  $sql = "SELECT c.conferenceID, c.name as cname, l.name, l.address, l.city, c.discipline, c.startDate, c.endDate
    FROM Conference c, Location l
    WHERE c.locationID = l.locationID".$cfid_clause.$cfname_clause.$cfcity_clause.$cfdisc_clause.$cfdate_clause;

      $page_result = $conn->query($sql);
      $total_records = mysqli_num_rows($page_result);
      $total_pages = ceil($total_records/$record_per_page);

     
?>
<div class="text-center">
<nav aria-label="Page navigation">
  <ul class="pagination justify-content-center">
    <li class="page-item disabled">
      <a class="page-link" href="13_viewAll.php?page=<?= $Previous; ?>" tabindex="-1">Previous</a>
    </li>
<?php for($i=1; $i<=$total_pages; $i++) : ?>

  <li ><a href="13_viewAll.php?page=<?= $i; ?>"><?= $i; ?></a></li>
<?php endfor; ?>

    <li class="page-item">
      <a class="page-link" href="13_viewAll.php?page=<?= $Next; ?>">Next</a>
    </li>
  </ul>
</nav>
</div>

<table id="myTable" class="table table-striped" width="100%" cellspacing="0">
    <tr>
    
      <br>
      <th>Learn More</th>
      <th>Name</th>
      <th>Location</th>
      <th>Address</th>
      <th>City</th>
      <th>Discipline</th>
      <th>Start Date</th>
      <th>End Date</th>
      <th>Register Now!</th>
    </tr>

      <?php
      if ($result) {
        while($row = $result->fetch_assoc()) {
        echo

        "
    <tbody>
        <tr>
        <td><a href=learnMoreEvents.php?conferenceID=". $row["conferenceID"] . ">Learn More</a></td>
        <td>" . stripslashes($row["cname"]) . "</td>
        <td>" . $row["name"] . "  </td>
        <td>" . $row["address"] . "</td>
        <td>" . $row["city"] . "</td>
        <td>" . $row["discipline"] . "</td>
        <td>" . $row["startDate"] . "</td>
        <td>" . $row["endDate"] . "</td>
        <td><a href=checkOut.php?conferenceID=". $row["conferenceID"] . ">Register</a></td>
        </tr>
        </tbody>";
          }
        }

      else {
        echo "0 results.";
      }
      ?>
  </table>


</div>



<script type="text/javascript">
  $(document).ready(function () {
  $('#myTable').DataTable();
  $('.dataTables_length').addClass('bs-select');
});
</script>
<?php
  // Close connection
  mysqli_close($conn);
?>
  <footer>
  © 2019 Copyright by ConferenceGate
</footer>


</body>
</html>