<?php
  session_start();

  $servername = "localhost";
  $username = "root";
  $password = "mysql";
  $dbname = "conferencegate";

// Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  } 

   $confID = $_GET["conferenceID"];
  
  // Get variables from form
  $cfnameraw = $_POST["cfname"];
  $cfcityraw = $_POST["cfcity"];
  $cfdiscraw = $_POST["cfdisc"];
  $cfcontraw = $_POST["contribution"];
  $cfeventraw = $_POST["event"];
  $cfid = $_POST["cfid"];
  $cfopen = $_POST["cfopenReg"];
  $cfname = strtolower($cfnameraw);
  $cfcity = strtolower($cfcityraw);
  $cfdisc = strtolower($cfdiscraw);
  $cfevent = strtolower($cfeventraw);
  $cfcont = strtolower($cfcontraw);
  $cfstartDate = $_POST["cfstartDate"];
  $cfstartDate2 = $_POST["cfstartDate2"];

  // Make clauses to construct SQL
  if($cfid){$cfid_clause = " AND c.conferenceID = ".$cfid." ";}
  if($cfname){$cfname_clause = "AND LOWER(c.name) LIKE '%".$cfname."%' ";}
  if($cfcity){$cfcity_clause = "AND LOWER(l.city) LIKE '%".$cfcity."%' ";}
  if($cfdisc){$cfdisc_clause = "AND LOWER(c.discipline) LIKE '%".$cfdisc."%' ";}
  if($cfevent){$cfdisc_clause = "AND LOWER(e.title) LIKE '%".$cfevent."%' ";}
  if($cont){$cfcont_clause = "AND LOWER(cn.title) LIKE '%".$cfcont."%' ";}
  if($cfstartDate && $cfstartDate2){$cfdate_clause = "AND LOWER(l.city) LIKE '%".$cfcity."%' ";}

  if($cfevent){$cfeventjoin = "AND e.conferenceID = c.conferenceID ";}
  if($cfcont){$cfcontjoin = "AND cn.conferenceID = c.conferenceID ";}

  // Run an sql
  $sql = "SELECT c.conferenceID, c.name as cname, l.name, l.address, l.city, c.discipline, c.startDate, c.endDate
    FROM Conference c, Location l, Contribution cn, Event e
    WHERE c.locationID = l.locationID ".$cfcontjoin.$cfeventjoin.$cfid_clause.$cfname_clause.$cfcity_clause.$cfdisc_clause.$cfdate_clause.$confID." GROUP BY c.conferenceID";
  $result = $conn->query($sql);
?>

<html>
<head>

     <meta charset="utf-8"> 
    <meta name="description" content="Bootstrap.">  
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">   
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css"></style>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

  <title>Search Results | Conference Gate</title>
</head>
  <div class="topnav">
  <a class="active" href="1_mainpage.php"><b><font color="black">Conference Gate</font></b></a>
  <a href="aboutUs.php"><b>About</b></a>
  <?php   
  // Check if user is logged in and assign logout buttons accordingly
    if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    echo "<a href='16_logout.php'>Logout</a>";
  echo "<div class='login-container'>
    <form action='/8_youraccount.php'>  
    <button type='submit'><b>My Account</b></button>
    </form>
    </div>";
  }
  
  if(!isset($_SESSION["loggedin"]) && !$_SESSION["loggedin"] === true) {
    echo"<div class='login-container'>
        <form action='/2_userregistration.php'>  
          <button type='submit'><b>Create New Account</b></button>
        </form>
      </div>

      <div class='login-container'>
        <form action='/3_login.php'>     
          <button type='submit'><b>Login</b></button>
        </form>
      </div>";
    }
  ?>
  </div>
</head>

<style type="text/css">
    /* Add a black background color to the top navigation */
.topnav {
  background-color: #318ce7;
  overflow: hidden;
}

/* Style the input container */
.topnav .login-container {
  float: right;
}

/* Style the button inside the input container */
.topnav .login-container button {
  float: right;
  padding: 6px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 14px;
  border: none;
  cursor: pointer;
}

/* Style when you hover on each tab */
.topnav .login-container button:hover {
  background: #ccc;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #ccc;
  color: white;
}
footer {
  background-color: black;
  padding: 7px;
  text-align: center;
  color: white;
  position: absolute;
  /* negative value of footer height */
  height: 30px;
  width: 100%;
  clear:both;
  bottom: 0;
  flex-shrink: 0;
}
</style>

<html>

<body>
<div class="container">
<table id="myTable" class="table table-striped" width="100%" cellspacing="0">
    <tr>
      <br><br>
      <b>Search Results<b>
      <br></br>
      <th>Show Events</th>
      <th>Name</th>
      <th>Location</th>
      <th>Address</th>
      <th>City</th>
      <th>Discipline</th>
      <th>Start Date</th>
      <th>End Date</th>
      <th>Register Now!</th>
    </tr>

      <?php
      if ($result) {
        while($row = $result->fetch_assoc()) {
        echo 
      
        "
        <tr>
        
        <td><a href=learnMoreEvents.php?conferenceID=". $row["conferenceID"] . ">Show Events</a></td>
        <td>" . stripslashes($row["cname"]) . "</td>
        <td>" . $row["name"] . "  </td>
        <td>" . $row["address"] . "</td>
        <td>" . $row["city"] . "</td>
        <td>" . $row["discipline"] . "</td>
        <td>" . $row["startDate"] . "</td>
        <td>" . $row["endDate"] . "</td>
        <td><a href=checkOut.php?conferenceID=". $row["conferenceID"] . ">Register</a></td>
        </tr>";
          }
        }

      else {
        echo "0 results.";
      }
      ?>

  </table>
</div>
  <?php
  // Close connection
  mysqli_close($conn);
  ?>

<footer>
  © 2019 Copyright by ConferenceGate
</footer>
</body>
</html>