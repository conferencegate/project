<?php
    $servername = "localhost";
    $username = "root";
    $password = "mysql";
    $database = "conferenceGate";
    $conn = new mysqli($servername, $username, $password, $database);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "";
    switch($_GET[action]){
      case 'conferencesbydiscipline': $sql = "SELECT c.discipline as n, COUNT(c.conferenceID) as t FROM conference c WHERE MONTH(c.startDate) = MONTH(CURRENT_TIMESTAMP()) GROUP BY n LIMIT 5";
      break;
      case 'highattn': $sql = "SELECT c.name as n, COUNT(r.userID) as t FROM conference c, registration r WHERE c.conferenceID = r.conferenceID AND YEAR(c.startDate) = YEAR(CURRENT_TIMESTAMP()) GROUP BY n";
      break;
      case 'hotlocation': $sql = "SELECT l.city as n, COUNT(c.conferenceID) as t from location l, conference c WHERE l.locationID = c.locationID AND MONTH(c.startDate) = MONTH(CURRENT_TIMESTAMP()) GROUP BY n LIMIT 5";
      break;
    }
    $result = $conn->query($sql);
    $output = "letter\tfrequency\n";
    if ($result){
      while($row = $result->fetch_assoc())
      {
          $output .= $row['n']."\t".$row['t']."\n"; 
      }
    }
    $result->free();
    echo $output;
    // Close connection
    mysqli_close($conn);
?>