<html>
<head>
    <div class="topnav">
  <a class="active" href="1_mainpage.php">Conference Gate</a>
  <a href="aboutUs.html">About</a>

<div class="login-container">
    <form action="/8_youraccount.php">  
      <button type="submit">My Account</button>
    </form>
  </div>

</div>


<style type="text/css">
        /* Add a black background color to the top navigation */
.topnav {
  background-color: #318ce7;
  overflow: hidden;
}

/* Style the input container */
.topnav .login-container {
  float: right;
}

/* Style the button inside the input container */
.topnav .login-container button {
  float: right;
  padding: 6px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 14px;
  border: none;
  cursor: pointer;
}

/* Style when you hover on each tab */
.topnav .login-container button:hover {
  background: #ccc;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #ccc;
  color: white;
}

</style>



<div class="main">
  <h1>My Account Information</h1>

</div>

<?php
$servername = "localhost";
$username = "root";
$password = "mysql";
$dbname = "conferencegate";

ini_set('max_execution_time',300);

// Create Connection 
$conn = new mysqli($servername, $username, $password, $dbname);

// Check Connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT firstName, lastName, discipline, organization, email FROM Attendee WHERE userID = 5";  //NEEED TO UPDATE THIS TO ONLY SHOW ACCOUNT INFO OF THE SIGNED IN USER!!!!! this is placeholder
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<table>";
  
    while ($row = mysqli_fetch_assoc($result)){

      echo
      "<tr><td>". 

      "First Name: " .
      $row['firstName'] . 
      "</tr><td>" . 

      "Last Name: " .
      $row['lastName'] . 
      "</tr><td>" . 

      "Discipline: " .
      $row['discipline'] . 
      "</tr><td>" . 

      "Organization: " .
      $row['organization'] . 
      "</tr><td>" .

      "Email: " .
      $row['email'] . 
      "</td></tr>";

   
  }
    echo "</table>";
} else {
  echo "0 results";
}
?>
</head>
</html>