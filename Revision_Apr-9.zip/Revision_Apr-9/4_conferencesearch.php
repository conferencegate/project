<html>
<head>
  <title>Search Conference | Conference Gate</title>
</head>
<head>
  <div class="topnav">
  <a class="active" href="1_mainpage.php">Conference Gate</a>
  <a href="aboutUs.html">About</a>

<div class="login-container">
    <form action="/2_userregistration.php">  
      <button type="submit">Create New Account</button>
    </form>
  </div>

  <div class="login-container">
    <form action="/3_login.php">     
      <button type="submit">Login</button>
    </form>
  </div>
</div>




<style type="text/css">
    /* Add a black background color to the top navigation */
.topnav {
  background-color: #318ce7;
  overflow: hidden;
}

/* Style the input container */
.topnav .login-container {
  float: right;
}

/* Style the button inside the input container */
.topnav .login-container button {
  float: right;
  padding: 6px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 14px;
  border: none;
  cursor: pointer;
}

/* Style when you hover on each tab */
.topnav .login-container button:hover {
  background: #ccc;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #ccc;
  color: white;
}

  </style>

  <style>
h1 {text-align:center;}
p {text-align:center;}
</style>




<?php
  session_start();
?>
<html>
  <head>
    <title>
      Search for a Conference
    </title>
  </head>
  <body><br>
    Search by one or more: </br>
    <form name="conferenceSearch" action= "12_searchResults.php" method="POST"></form>
      Conference ID: <input type="text" name="cfid"></br>
      Conference Name:<input type="text" name="cfname"></br>
      City:<input type="text" name="cfcity"></br>
      Start Date Between: <input type="date" name="cfstartDate"> and <input type="date" name="cfstartDate2"></br>
      <input type="checkbox" name="cfopenReg" value="openOnly"> Only Show Conferences with Open Registration<br>
      </select> 
      </br>
      <input type="button" value="submit" onclick="window.location.href='12_searchResults.php'" />
    </form>
  </body>
</html>